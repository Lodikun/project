<?php
session_start();

include("connection.php");
include("functions.php");

if (!isset($_SESSION['username'])) {
  if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['register'])) {
      $username = filter_var($_POST['Username'], FILTER_SANITIZE_STRING);
      $email = filter_var($_POST['Email'], FILTER_SANITIZE_EMAIL);
      $password = $_POST['Password'];

      // Validate user input
      if (empty($username) || empty($email) || empty($password)) {
          echo '<script type="text/javascript">alert("Please fill in all the fields.");</script>';
      } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
          echo '<script type="text/javascript">alert("Invalid email address.");</script>';
      } elseif (strlen($password) < 6) {
          echo '<script type="text/javascript">alert("Password must be at least 6 characters long.");</script>';
      } else {
          // Use PDO to insert data safely
          $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

          try {
              $stmt = $conn->prepare("INSERT INTO `users` (username, email, password) VALUES (?, ?, ?)");
              $stmt->execute([$username, $email, $hashedPassword]);

              // Registration successful
              $_SESSION['registration_success'] = true;
          } catch (PDOException $e) {
              // Handle any database error
              echo '<script type="text/javascript">alert("An error occurred during registration: ' . $e->getMessage() . '");</script>';
          }
      }
  }
}

if (isset($_SESSION['registration_success']) && $_SESSION['registration_success'] === true) {
  echo '<script type="text/javascript">alert("Registration successful!");</script>';
  // Unset the session variable to prevent showing the message again on page refresh
  unset($_SESSION['registration_success']);
}
if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['login'])) {
  $username = filter_var($_POST['Username'], FILTER_SANITIZE_STRING);
  $password = $_POST['Password'];

  // Validate user input
  if (empty($username) || empty($password)) {
      echo '<script type="text/javascript">alert("Please fill in both fields.");</script>';
  } else {
      // Check if the user exists in the database
      $sql = "SELECT * FROM `users` WHERE username = ?";
      $stmt = $conn->prepare($sql);
      $stmt->bind_param("s", $username);
      $stmt->execute();
      $result = $stmt->get_result();

      if ($result->num_rows === 1) {
          $row = $result->fetch_assoc();
          $hashed_password = $row['password'];

          // Verify the password
          if (password_verify($password, $hashed_password)) {
              // Login successful
              $_SESSION['username'] = $username; // Store the username in the session
              header("Location: ./index.php"); // Redirect to the desired page after login
          } else {
              echo '<script type="text/javascript">alert("Incorrect password.");</script>';
          }
      } else {
          echo '<script type="text/javascript">alert("User not found.");</script>';
      }
  }
}
?>





<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Lily Bead</title>
    <link rel="stylesheet" type="text/css" href="./test1.css" />
    <script
      src="https://kit.fontawesome.com/64d58efce2.js"
      crossorigin="anonymous"
    ></script>
  
  </head>
  <body>
    <div class="container">
      <div class="forms-container">
        <div class="signin-signup">
          <form action="" method="POST" class="sign-in-form">
            <h2 class="title">Sign In</h2>
            <div class="input-field">
              <i class="fas fa-user"></i>
              <input type="text" name="Username" placeholder="Username" />
            </div>
            <div class="input-field">
              <i class="fas fa-lock"></i>
              <input type="password" name="Password" placeholder="Password" />
            </div>
            <input action="signin.php" type="submit" name="login" value="Login" class="btn solid" />


          </form>


          <form action="" class="sign-up-form" method="POST">
            <h2 class="title">Sign Up</h2>
            <div class="input-field">
              <i class="fas fa-user"></i>
              <input type="text" name="Username" placeholder="Username" />
            </div>
            <div class="input-field">
              <i class="fas fa-envelope"></i>
              <input type="email" name="Email" placeholder="Email" />
            </div>
            <div class="input-field">
              <i class="fas fa-lock"></i>
              <input type="password" name="Password" placeholder="Password" />
            </div>
            <input type="submit" name="register" value="Sign Up" class="btn solid" />

          </form>
        </div>
      </div>
      <div class="panels-container">

        <div class="panel left-panel">
            <div class="content">
                <h3>New here?</h3>
                <p>Sign up for free</p>
                <button class="btn transparent" id="sign-up-btn">Sign Up</button>
            </div>
            
        </div>

        <div class="panel right-panel">
            <div class="content">
                <h3>Lily Bead</h3>
                <p>Est. 2023</p>
                <button class="btn transparent" id="sign-in-btn">Sign In</button>
            </div>
    
        </div>
      </div>
    </div>

    

    <script src="./test2.js"></script>
  </body>
</html>