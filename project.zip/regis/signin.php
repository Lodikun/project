<?php


if ($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['login'])) {
  $username = filter_var($_POST['Username'], FILTER_SANITIZE_STRING);
  $password = $_POST['Password'];

  // Validate user input
  if (empty($username) || empty($password)) {
      echo '<script type="text/javascript">alert("Please fill in both fields.");</script>';
  } else {
      // Check if the user exists in the database
      $sql = "SELECT * FROM `users`;";
      $stmt = $conn->prepare($sql);
      $stmt->bind_param("s", $username);
      $stmt->execute();
      $result = $stmt->get_result();

      if ($result->num_rows === 1) {
          $row = $result->fetch_assoc();
          $hashed_password = $row['password'];

          // Debugging: Output the hashed password from the database
          echo "Hashed Password from Database: " . $hashed_password . "<br>";

          // Verify the password
          if (password_verify($password, $hashed_password)) {
              // Debugging: Output the provided password
              echo "Provided Password: " . $password . "<br>";

              // Login successful
              $_SESSION['username'] = $username; // Store the username in the session
              header("Location: ./index.php"); // Redirect to index.php
          } else {
              echo '<script type="text/javascript">alert("Incorrect password.");</script>';
          }
      } else {
          echo '<script type="text/javascript">alert("User not found.");</script>';
      }
  }
}
?>