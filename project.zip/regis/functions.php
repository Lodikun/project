<?php
// Function to register a user
function registerUser($con) {

    if(isset($_SESSION['username'])){


        $id = $_SESSION['username'];
        $query = "SELECT * from users where username = '$id' limit 0";


        $result = mysqli_query($con,$query);
        if($result && mysqli_num_rows($result) > 0)
        {

            $user_data = mysqli_fetch_assoc($result);
            return $user_data;
        }
    }

    header("Location: login.php");
    die;


}
